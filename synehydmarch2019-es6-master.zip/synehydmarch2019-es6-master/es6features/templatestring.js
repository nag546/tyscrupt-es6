let fname = "Mahesh";
let mname = "Ramesh";
let lname = "Sabnis";

console.log(`Traditional Concatination`);
let fullName = fname + " " + mname + " " + lname;

console.log();
console.log(`ES 6 Template String`);
let fullName1 = `The Full Name is ${fname} 
                ${mname} ${lname}`;
console.log(fullName1);

console.log(`Add = ${2+3}`);
console.log(`Mult = ${2*3}`);